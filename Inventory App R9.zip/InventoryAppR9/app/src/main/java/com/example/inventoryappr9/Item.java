package com.example.inventoryappr9;

import java.io.Serializable;

/**
 * This class creates the Item objects which are elements of the inventory database data member
 * within the user class
 * <p>Implements Serializable to enable JSON GSON serialization for saving functionality</p>
 */
public class Item implements Serializable {
    // Private data members
    private int count;
    private String name;

    // Empty Constructor - Needed for serialization/deserialization
    public Item() {}
    // Constructor with Name and Count
    public Item(String name, int count) {
        this.name = name;
        this.count = count;
    }

    /// Setters and Getters ///

    public void setCount(int count) {
        this.count = count;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public String getName() {
        return name;
    }

}
