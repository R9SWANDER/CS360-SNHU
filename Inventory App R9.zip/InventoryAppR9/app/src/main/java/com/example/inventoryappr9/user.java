package com.example.inventoryappr9;
import com.example.inventoryappr9.Item;
import java.util.LinkedList;
import java.util.Iterator;
import java.io.Serializable;

/**
 * Class that provides the basis for user data
 * <p>Houses a Linked list of Inventory items to provide a user specific inventory</p>
 * <p>Implements serialization to enable saving functionality via JSON-GSON</p>
 */
public class user implements Serializable {
    // Private Data members
    private String username;
    private String password;
    private String phoneNumber;

    // The inventory list
    private LinkedList<Item> database = new LinkedList<>();

    // Empty constructor
    public user() {}

    // Constructor with Username/Password
    public user(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Constructor with Username/Password/Phone Number
    public user(String username, String password, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    /// Getters and Setters ///

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String newPassword) {
        password = newPassword;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setDatabase(LinkedList<Item> database) {
        this.database = database;
    }

    public LinkedList<Item> getDatabase() {
        return database;
    }

    public void addItem(Item item) {
        database.add(item);
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /// Special removing Item Functions ///

    public void deleteItemByName(String item) {
        for (Item element : database) {
            // Find item that matches name and delete it
            if (element.getName().equals(item)) {
                database.remove(element);
            }
        }
    }

    public void deleteItemByItem(Item item) {
        for (Item element : database) {
            // Find item that matches item and delete it
            if (element == item) {
                database.remove(element);
            }
        }
    }
}
