///  Created By: Reece Neuenschwander - 2/17/26
package com.example.inventoryappr9;

import com.example.inventoryappr9.Item;
import com.example.inventoryappr9.user;
import com.example.inventoryappr9.userManager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.text.Editable;
import android.widget.Button;
import android.util.Log;
import android.widget.Toast;


import java.util.LinkedList;
import java.util.Iterator;

/// Note to Viewer ///
/// Test username with preloaded data :
/// Username: r
/// Password: r


/**
 * The Main activity is the opening layout for the application, housing log in
 * functionality and functions for creating new users.
 */
public class MainActivity extends AppCompatActivity {

    // Private variables -- Main Layout objects
    private EditText usernameEdit;
    private EditText passwordEdit;
    private EditText phoneNumberEdit;
    private Button confirmLogin;
    private Button createNewLogin;
    private LinkedList<user> userMasterList; // Linked List Driving all data saving functions

    /**
     * Method called on application opening - initializes the application
     *
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Setting layout
        setContentView(R.layout.main_activity);

        // Retrieving saved data
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        String savedUserMasterList = prefs.getString("users_json", null);
        userMasterList = userManager.deserializeUsers(savedUserMasterList);

        // Assigning view objects
        usernameEdit = findViewById(R.id.usernameEdit);
        passwordEdit = findViewById(R.id.passwordEdit);
        phoneNumberEdit = findViewById(R.id.phoneNumberEdit);
        confirmLogin = findViewById(R.id.confirmLogin);
        createNewLogin = findViewById(R.id.createNewLogin);
    }

    /**
     * Triggers saving if the app is stopped (closing or opening another app)
     * <p>DOES NOT TRIGGER IF RED STOP IS PRESSED WITHIN IDE
     */
    @Override
    protected void onStop() {
        super.onStop();

        // Saving block
        String newUserMasterList = userManager.serializeUsers(userMasterList);
        Log.d(userManager.TAG, "onStop(): newUserListJustWritten(Json): " + newUserMasterList);
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        prefs.edit().putString("users_json", newUserMasterList).apply();
    }

    /**
     * Method used to create a new user - with rules
     * <p>Phone number is not required but will disable text messaging if left empty</p>
     * <ul>
     *     <li>Username cannot have special characters</li>
     *     <li>Password cannot have special characters</li>
     *     <li>Phone number must be all numbers</li>
     *     <li>Phone number must be exactly 10 digits</li>
     * </ul>
     * @param view the view object tied to this action -  the create button
     */
    public void createNewUser(View view) {

        // Reading user input
        String currentUsername = usernameEdit.getText().toString().strip();
        String currentPassword = passwordEdit.getText().toString().strip();
        String currentPhoneNumber = phoneNumberEdit.getText().toString().strip();

        // Evaluating user input emptiness
        boolean usernameIsEmpty = TextUtils.isEmpty(currentUsername);
        boolean passwordIsEmpty = TextUtils.isEmpty(currentPassword);

        // Evaluating user input format
        boolean usernameIsValid = userManager.validateString(currentUsername);
        boolean passwordIsValid = userManager.validateString(currentPassword);
        boolean phoneNumberValid = userManager.validateNumber(currentPhoneNumber);

        /// Validation Gates ///

        // If wrong format
        if (!usernameIsValid || !passwordIsValid) {
            Toast.makeText(this, "Username or Password Invalid: No Special Characters Allowed", Toast.LENGTH_SHORT).show();
            return;
        }

        // If not empty -- Normal Functionality
        if (!usernameIsEmpty && !passwordIsEmpty) {
            // Create the user with data provided
            user newUser = new user(currentUsername, currentPassword);

            // If phone number valid, add it
            if (phoneNumberValid) {
                newUser.setPhoneNumber(currentPhoneNumber);
            }
            // If not - Error
            else {
                Toast.makeText(this, "Phone Number Invalid or Not Provided: Text Notifications Disabled" + newUser.getUsername(), Toast.LENGTH_SHORT).show();
            }

            // Validate new user is not already taken
            for (user user : userMasterList) {
                if (user.getUsername().equals(newUser.getUsername())) {
                    Toast.makeText(this, "Username Invalid: This Username is Already in Use", Toast.LENGTH_SHORT).show();
                    return; // Does not add the created user
                }
            }

            // Add user to MasterList if all gates passed
            userMasterList.add(newUser);
            Toast.makeText(this, "User Successfully Created: " + newUser.getUsername(), Toast.LENGTH_SHORT).show();
        }
        // If empty - Error
        else {
            Toast.makeText(this, "Username or Password Invalid: Username or Password Empty", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    /**
     * Method for checking for a matching user, and taking the user to the inventory screen
     * <p>Phone number is not a required field</p>
     * @param view the view tied to this action - The log in button
     */
    public void logIn(View view) {
        // Get user input and validate it
        String currentUsername = usernameEdit.getText().toString().strip();
        String currentPassword = passwordEdit.getText().toString().strip();
        boolean usernameIsEmpty = TextUtils.isEmpty(currentUsername);
        boolean passwordIsEmpty = TextUtils.isEmpty(currentPassword);

        // Iterate through userMasterList
        Iterator<user> iterator = userMasterList.iterator();

        // If the username and password fields are each not empty
        if (!usernameIsEmpty && !passwordIsEmpty) {
            // While theres more users in the userMasterList
            while (iterator.hasNext()) {
                user nextUser = iterator.next();
                // If username and password match
                if (nextUser.getUsername().equals(currentUsername) && nextUser.getPassword().equals(currentPassword)) {

                    // Movement to next activity
                    Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                    // Storing data for reference in inventory class to sync user activity
                    intent.putExtra("current_User", nextUser);
                    intent.putExtra("username", nextUser.getUsername());

                    // Activating inventory screen
                    startActivity(intent);
                }
            }
        }
    }
}


