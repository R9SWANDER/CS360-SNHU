package com.example.inventoryappr9;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.LinkedList;

public class InventoryActivity extends AppCompatActivity {

    /// Private variables and constants ///
    // Layout elements
    private ScrollView scrollTable;
    private LinearLayout inventoryTable;
    private LinkedList<user> userMasterList;
    private LinkedList<Item> inventoryList;
    private FloatingActionButton fabAddItem;
    private FrameLayout addItemContainer;

    // Constants
    private final int ITEM_NAME_MAX_LENGTH = 14;
    private final int ITEM_COUNT_MAX_LENGTH = 4;
    private final int ITEM_COUNT_MAX = 9999;
    private final int ITEM_COUNT_MIN = 0;


    /**
     * Launches the layout and activity
     *
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *     previously being shut down then this Bundle contains the data it most
     *     recently supplied in {@link #onSaveInstanceState}.  <b><i>Note: Otherwise it is null.</i></b>
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Initializing layout
        setContentView(R.layout.inventory);

        // Getting in-instance user --> passed from log in
        user currentUser = (user) getIntent().getSerializableExtra("current_User");

        // Called here to retrieve the saved userMasterList
        applyChanges();

        // Reading layout elements
        scrollTable = findViewById(R.id.scrollTable);
        inventoryList = currentUser.getDatabase();
        inventoryTable = findViewById(R.id.linearLayout);
        addItemContainer = findViewById(R.id.addItemContainer);
        fabAddItem = findViewById(R.id.fabAddItem);
        int added = 0; // for debug use

        // build table
        refreshTable(currentUser);

        // Action button listener that calls the add item menu to open
        fabAddItem.setOnClickListener( v -> {
            Log.d("Inventory","Inventory: FAB Clicked - showing AddItemMenu()" );
            showAddItemMenu();
        });

        // SMS permission requested at this step in case an item is updated to 0
        requestSmsPermission();
    }

    /**
     * Triggers saving if the app is stopped (closing or opening another app)
     * <p>DOES NOT TRIGGER IF RED STOP IS PRESSED WITHIN IDE
     */
    @Override
    protected void onStop() {
        super.onStop();
        String newUserMasterList = userManager.serializeUsers(userMasterList);
        Log.d(userManager.TAG, "onStop()-Inventory: newUserListJustWritten(Json): " + newUserMasterList);
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        prefs.edit().putString("users_json", newUserMasterList).apply();
    }

    /**
     * SMS Permission Requester
     */
    public void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, 100);
            Log.d("SMS", "Requesting permission");
        }
        else {
            Log.d("SMS", "Permission already granted");
        }
    }

    /**
     *
     * SMS Permission Handler
     *
     * @param requestCode The request code passed in {@link #requestPermissions}.
     * @param permissions The requested permissions. Never null.
     * @param grantResults The grant results for the corresponding permissions which is either
     *                     {@link android.content.pm.PackageManager#PERMISSION_GRANTED} or
     *                     {@link android.content.pm.PackageManager#PERMISSION_DENIED}. Never null.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("SMS", "permission granted");
                Toast.makeText(this, "Text Notifications Enabled", Toast.LENGTH_SHORT).show();
            } else {
                Log.d("SMS", "permission denied");
                Toast.makeText(this, "Text Notifications Disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * This method creates the table and houses the functions of the table
     * for use by the user based on the stored data in the in-instance userMasterList
     * <ul>
     *     <li>Building the Table</li>
     *     <li>Updating item counts</li>
     *     <li>Deleting items</li>
     *     <li>Sending out of stock notifications</li>
     * </ul>
     *
     * @param currentUser the user object in-instance, corresponding to the user logged in
     */
    public void refreshTable(user currentUser) {

        /// Initializing Table ///
        inventoryTable.removeAllViews();
        inventoryList = currentUser.getDatabase();
        Log.d("Refresh", "userDatabaseFound: " + currentUser.getDatabase());
        int added = 0;
        SmsManager smsManager = SmsManager.getDefault();

        /// Building Table ///

        // Each row of the table is one iteration
        for (Item item : inventoryList) {

            // The row and attributes
            LinearLayout row = new LinearLayout(this);
            Log.d("Refresh", "Creating Table Item: " + item.getName() + " " + item.getCount());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setBackgroundColor(Color.LTGRAY);
            row.setMinimumHeight(130);
            row.setPadding(10, 10, 10, 10);

            // text box to hold text in the row
            TextView theItem = new TextView(this);

            /// Formatting Text Output ///
            // Formatting the strings
            String spacedName = item.getName();
            String spacedCount = String.format("%" + ITEM_COUNT_MAX_LENGTH + "s", item.getCount());

            // Formatting the whitespace to be uniform
            int whiteSpaceCount = ITEM_NAME_MAX_LENGTH - item.getName().length();
            String whiteSpace = "";
            for (int i = whiteSpaceCount; i > 1; i--) {
                whiteSpace = whiteSpace + " ";
            }

            // Final string print out
            String spacedRow = spacedName + whiteSpace + spacedCount;
            Log.d("TableGeneration", "Row: " + added + " Length: " + spacedRow.length()
            + " Original: " + spacedName.length() + " " + whiteSpace.length() + " " + spacedCount.length());

            // Attributes of the text box
            theItem.setText(spacedRow);
            theItem.setTextSize(22f);
            theItem.setTextColor(Color.BLACK);
            theItem.setPadding(20, 10, 20, 10);
            theItem.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            theItem.setTypeface(Typeface.MONOSPACE); // Very important for uniformity - uniform char sizes

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1f
            );

            // Logging and adding the finished text box to the row
            added++;
            row.addView(theItem, params);
            row.setBackgroundColor(Color.LTGRAY);

            /// Button 1 - Adding to the Count ///
            // Button Attributes
            Button btnIncrement = new Button(this);
            btnIncrement.setText("+");
            btnIncrement.setBackgroundColor(Color.GREEN);
            btnIncrement.setTextSize(16f);
            btnIncrement.setMaxWidth(80);
            btnIncrement.setPadding(12, 8, 12, 8);
            LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                    100,
                    80

            );
            btnParams.setMargins(8, 0, 8, 0);

            // Button Functionality --> ++1
            btnIncrement.setOnClickListener(v -> {
                item.setCount(item.getCount() + 1);
                // updating, saving and rebuilding
                updateUserMasterList(currentUser);
                saveChanges();
                refreshTable(currentUser);
            });
            // Adding button to row
            row.addView(btnIncrement,btnParams);

            /// Button 2 - subtracting from the count ///
            // Button Attributes
            Button btnDecrement = new Button(this);
            btnDecrement.setText("-");
            btnDecrement.setTextSize(16f);
            btnDecrement.setBackgroundColor(Color.YELLOW);
            btnDecrement.setMaxWidth(80);
            btnDecrement.setPadding(12, 8, 12, 8);

            // Button Functionality --> --1 & SMS Notifications
            btnDecrement.setOnClickListener(v -> {
                // Cant go less than 0
                if (item.getCount() > 0) {
                    item.setCount(item.getCount() - 1);
                    // If user allows SMS
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                            == PackageManager.PERMISSION_GRANTED) {
                        // If the count is at 0 after the change
                        if (item.getCount() == ITEM_COUNT_MIN) {
                            Log.d("SMS", "Sending out of stock notification");
                            smsManager.sendTextMessage(currentUser.getPhoneNumber(), null,
                                    "Item: " + item.getName() + " is out of stock!",
                                    null, null);
                            // Notifying user text was sent
                            Toast.makeText(this, "Out of Stock Message Sent to: " + currentUser.getPhoneNumber() + " for " + item.getName(), Toast.LENGTH_SHORT).show();
                        }
                    }
                    // Updating, saving and rebuilding
                    updateUserMasterList(currentUser);
                    saveChanges();
                    refreshTable(currentUser);
                }
            });
            // adding button to row
            row.addView(btnDecrement,btnParams);

            /// Button 3 - Deleting ///
            // Button Attributes
            Button btnDelete = new Button(this);
            btnDelete.setText("x");
            btnDelete.setBackgroundColor(Color.RED);
            btnDelete.setTextSize(16f);
            btnDelete.setMaxWidth(80);
            btnDelete.setPadding(12, 8, 12, 8);

            btnParams.setMargins(8, 0, 8, 0);
            // Button functionality --> removing the item from the user's inventory
            btnDelete.setOnClickListener(v -> {
                currentUser.deleteItemByItem(item);
                // Updating, saving and rebuilding
                updateUserMasterList(currentUser);
                saveChanges();
                refreshTable(currentUser);
            });
            // adding button to row
            row.addView(btnDelete, btnParams);

            // Adding row to layout
            inventoryTable.addView(row);
            Log.d("Refresh", "Created Row # " + added + " Item: " + item.getName());
        }
    }

    /**
     * This method houses the add new item pop-up menu and all functions related to it
     * <p>
     *   <ul>
     *       <li>Opening the pop-up</li>
     *       <li>Reading of name and count input for the item</li>
     *       <li>Validation of inputs</li>
     *       <li>Updating the saved userMasterList after an item is added</li>
     *       <li>Closing the pop-up</li>
     *   </ul>
     *
     */
    public void showAddItemMenu() {

        /// Opening the menu ///

        LayoutInflater inflater = getLayoutInflater();
        View addItemMenu = inflater.inflate(R.layout.add_item, addItemContainer, true);
        // Getting username of logged in user for saving and referencing purposes
        String currentUsername = getIntent().getSerializableExtra("username").toString();
        // Making the layout visible
        addItemContainer.setVisibility(View.VISIBLE);

        // Initializing menu for reading //
        EditText addItemCurrentName = findViewById(R.id.nameField);
        EditText addItemCurrentCount = findViewById(R.id.countField);
        Button submitItem = findViewById(R.id.submitItem);
        Button addItemCancel = findViewById(R.id.addItemCancel);

        /// Button Listeners ///

        // Closes menu when X is pushed
        addItemCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItemContainer.setVisibility(View.GONE);
                addItemContainer.removeAllViews();
            }
        });

        // Adds an item according to user inputs when submit is pressed
        submitItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // reading user inputs
                String itemName = addItemCurrentName.getText().toString().strip();
                String itemCount = addItemCurrentCount.getText().toString().strip();

                // validation of input
                boolean itemNameValid = userManager.validateString(itemName);
                boolean itemCountValid = userManager.validateNumber(itemCount);

                /// Exception Branches ///

                // If theres any completely empty input or bad character types
                if (itemName.isEmpty() || itemCount.isEmpty() || !itemNameValid || !itemCountValid) {
                    Toast.makeText(addItemContainer.getContext(), "Item Not Added Error: Name or Count Character Usage Exception", Toast.LENGTH_SHORT).show();
                    Log.d("AddItem","itemFieldEmptyError");
                }
                // Name length too long (max 14)
                else if (itemName.length() > ITEM_NAME_MAX_LENGTH ) {
                    Toast.makeText(addItemContainer.getContext(), "Item Not Added Error: Name Length Too Long", Toast.LENGTH_SHORT).show();
                }
                // Item count length too long (max 4/abs value > 9999)
                else if (itemCount.length() > ITEM_COUNT_MAX_LENGTH) {
                    Toast.makeText(addItemContainer.getContext(), "Item Not Added Error: Count Too Large", Toast.LENGTH_SHORT).show();
                }

                /// Normal Functionality ///

                // No exceptions
                else {
                    // Formating and creating new item object
                    int itemCountInt = Integer.parseInt(itemCount);
                    Item newItem = new Item(itemName, itemCountInt);
                    Log.d("AddItem","newItemCreated");

                    // Finding matching user in userMasterList in instance and updating it
                    for (user user : userMasterList) {
                        Log.d("AddItem","Iterating through userMasterList");
                        if(user.getUsername().equals(currentUsername)) {
                            user.addItem(newItem); // Adding new item to the user
                            saveChanges();         // Permanently saving changes
                            applyChanges();        // Reloading newly changed userMasterList
                            refreshTable(user);    // Rebuilding table based on new data
                            Log.d("Inventory", "Inventory: User updated in instance");
                        }
                    }
                }
                // Closing the layout and clearing it for next use
                addItemContainer.setVisibility(View.GONE);
                addItemContainer.removeAllViews();
            }
        });
    }

    /**
     *  Saves changes made to the user, by updating the saved userMasterList
     *  <p>
     *      User information is saved using JSON serialization, stored in the user's
     *      shared preferences
     */
    public void saveChanges() {
        String newUserMasterList = userManager.serializeUsers(userMasterList);
        Log.d("Inventory", "Inventory: saveChanges(), new masterList saved" + newUserMasterList);
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        prefs.edit().putString("users_json", newUserMasterList).apply();
    }

    /**
     * Applies changes made to the user, by calling the saved userMasterList and assigning it to
     * the in-instance userMasterList
     * <p>
     *     User information is updated in-instance by deserialization of the JSON string
     *     stored in the user's shared preferences
     */
    public void applyChanges() {
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        String savedUserMasterList = prefs.getString("users_json", null);
        userMasterList = userManager.deserializeUsers(savedUserMasterList);
        Log.d("Inventory","UserMasterList Assigned");
    }

    /**
     * Updates the in-instance list of users to prepare to save changes
     *
     * @param currentUser the user object in-instance corresponding to the user logged in
     *
     */
    public void updateUserMasterList(user currentUser) {

        for (int i = 0; i < userMasterList.size(); i++) {
            user userAtIndex = userMasterList.get(i);
            if (userAtIndex.getUsername().equals(currentUser.getUsername())) {
                userMasterList.set(i, currentUser);
                return;
            }
        }
    }

}
