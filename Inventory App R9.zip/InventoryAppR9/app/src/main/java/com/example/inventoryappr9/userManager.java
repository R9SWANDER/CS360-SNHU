package com.example.inventoryappr9;
import com.example.inventoryappr9.user;
import java.util.LinkedList;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import android.util.Log;

/**
 * Saves and loads the user data using JSON serialization and deserialization through Gson
 * <p>
 *     Also houses the validation methods used by both the log in and add item classes
 * </p>
 */
public class userManager {

    private static final Gson gson = new Gson();
    public static final String TAG = "SavingFunctions"; // Used for debugging in LogCat

    /**
     * Serializes the userMasterList -- a linked list of user objects
     * each of which also contain a nested linked list of items along with user information
     *
     * @param userMasterList
     * @return returns the userMasterList, serialized and ready to save
     */
    public static String serializeUsers(LinkedList<user> userMasterList) {
        if (userMasterList == null || userMasterList.isEmpty()) {
            Log.d(TAG, "serializeUsers(): empty or null return trigger -> empty array saved");
            return "[]"; // Empty Json Array
        }
        return gson.toJson(userMasterList);
    }

    /**
     * Takes the saved JSON userMasterList and deserializes it to prepare it to be loaded in-instance
     *
     * @param json
     * @return
     */
    public static LinkedList<user> deserializeUsers(String json) {
        if (json == null || json.trim().isEmpty()) {
            Log.d(TAG, "deserializeUsers(): empty or null return trigger -> New list returned");
            return new LinkedList<>();
        }

        Type userLinkedListType = new TypeToken<LinkedList<user>>() {}.getType();
        LinkedList<user> loadedUsers = gson.fromJson(json, userLinkedListType);
        Log.d(TAG, "deserializeUsers(): Loaded " + loadedUsers.size() + " users" );
        for (user element : loadedUsers) {
            Log.d(TAG, "deserializeUsers(): Element Number: " +
                    loadedUsers.indexOf(element) + ", " +
                    "Username: " + element.getUsername());
        }
        return loadedUsers;
    }

    /**
     * Validates a string does not have special characters
     *
     * @param string to be validated
     * @return true = no special characters
     */
    public static boolean validateString(String string) {
        // For + Switch per character
        for (int i = 0; i < string.length(); i++) {
            switch (string.charAt(i)) {
                case '!':
                case '@':
                case '#':
                case '$':
                case '%':
                case '^':
                case '&':
                case '*':
                case '(':
                case ')':
                case '-':
                case '_':
                case '+':
                case '=':
                case '[':
                case ']':
                case '{':
                case '}':
                case '\\':
                case '|':
                case ';':
                case ':':
                case ',':
                case '.':
                case '/':
                case '?':
                    return false; // Fall through = Fail
                default:
                    break; // Default = break -> Exit Loop -> True
            }
        }
        return true;
    }

    /**
     * Validates a string as only possessing numbers and is length 10
     *
     * @param number to be validated
     * @return true = is only numbers
     */
    public static boolean validateNumber(String number) {
        // Special character evaluation
        boolean valid = validateString(number);
        // If no special characters
        if (valid) {
            // For + Switch for each character in string
            for (int i = 0; i < number.length(); i++) {
                switch (number.charAt(i)) {
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                    case '0':
                        break; // Fall through break
                    default:   // Default = Fail
                        return false;
                }
            }
        }
        // Length check if for loop passed
        if (number.length() == 10) {
            return true;
        }
        else {
            return false;
        }
    }
}
